namespace Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Models.Api201908Preview
{
    using static Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Extensions;

    /// <summary>The async operation body for srp request.</summary>
    public partial class AsyncOperationModel
    {

        /// <summary>
        /// <c>AfterFromJson</c> will be called after the json deserialization has finished, allowing customization of the object
        /// before it is returned. Implement this method in a partial class to enable this behavior
        /// </summary>
        /// <param name="json">The JsonNode that should be deserialized into this object.</param>

        partial void AfterFromJson(Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonObject json);

        /// <summary>
        /// <c>AfterToJson</c> will be called after the json erialization has finished, allowing customization of the <see cref="Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonObject"
        /// /> before it is returned. Implement this method in a partial class to enable this behavior
        /// </summary>
        /// <param name="container">The JSON container that the serialization result will be placed in.</param>

        partial void AfterToJson(ref Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonObject container);

        /// <summary>
        /// <c>BeforeFromJson</c> will be called before the json deserialization has commenced, allowing complete customization of
        /// the object before it is deserialized.
        /// If you wish to disable the default deserialization entirely, return <c>true</c> in the <see "returnNow" /> output parameter.
        /// Implement this method in a partial class to enable this behavior.
        /// </summary>
        /// <param name="json">The JsonNode that should be deserialized into this object.</param>
        /// <param name="returnNow">Determines if the rest of the deserialization should be processed, or if the method should return
        /// instantly.</param>

        partial void BeforeFromJson(Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonObject json, ref bool returnNow);

        /// <summary>
        /// <c>BeforeToJson</c> will be called before the json serialization has commenced, allowing complete customization of the
        /// object before it is serialized.
        /// If you wish to disable the default serialization entirely, return <c>true</c> in the <see "returnNow" /> output parameter.
        /// Implement this method in a partial class to enable this behavior.
        /// </summary>
        /// <param name="container">The JSON container that the serialization result will be placed in.</param>
        /// <param name="returnNow">Determines if the rest of the serialization should be processed, or if the method should return
        /// instantly.</param>

        partial void BeforeToJson(ref Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonObject container, ref bool returnNow);

        /// <summary>
        /// Deserializes a Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonObject into a new instance of <see cref="AsyncOperationModel" />.
        /// </summary>
        /// <param name="json">A Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonObject instance to deserialize from.</param>
        internal AsyncOperationModel(Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonObject json)
        {
            bool returnNow = false;
            BeforeFromJson(json, ref returnNow);
            if (returnNow)
            {
                return;
            }
            {_context = If( json?.PropertyT<Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonObject>("context"), out var __jsonContext) ? Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Models.Api201908Preview.OperationRequestContext.FromJson(__jsonContext) : Context;}
            {_operation = If( json?.PropertyT<Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonObject>("operation"), out var __jsonOperation) ? Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Models.Api201908Preview.AsyncOperation.FromJson(__jsonOperation) : Operation;}
            {_httpStatus = If( json?.PropertyT<Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonString>("httpStatus"), out var __jsonHttpStatus) ? (string)__jsonHttpStatus : (string)HttpStatus;}
            {_id = If( json?.PropertyT<Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonString>("id"), out var __jsonId) ? (string)__jsonId : (string)Id;}
            {_locationHeader = If( json?.PropertyT<Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonString>("locationHeader"), out var __jsonLocationHeader) ? (string)__jsonLocationHeader : (string)LocationHeader;}
            {_operationEndTime = If( json?.PropertyT<Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonString>("operationEndTime"), out var __jsonOperationEndTime) ? (string)__jsonOperationEndTime : (string)OperationEndTime;}
            {_operationStartTime = If( json?.PropertyT<Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonString>("operationStartTime"), out var __jsonOperationStartTime) ? (string)__jsonOperationStartTime : (string)OperationStartTime;}
            {_response = If( json?.PropertyT<Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonString>("response"), out var __jsonResponse) ? (string)__jsonResponse : (string)Response;}
            {_subscriptionId = If( json?.PropertyT<Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonString>("subscriptionId"), out var __jsonSubscriptionId) ? (string)__jsonSubscriptionId : (string)SubscriptionId;}
            AfterFromJson(json);
        }

        /// <summary>
        /// Deserializes a <see cref="Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonNode"/> into an instance of Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Models.Api201908Preview.IAsyncOperationModel.
        /// </summary>
        /// <param name="node">a <see cref="Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonNode" /> to deserialize from.</param>
        /// <returns>
        /// an instance of Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Models.Api201908Preview.IAsyncOperationModel.
        /// </returns>
        public static Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Models.Api201908Preview.IAsyncOperationModel FromJson(Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonNode node)
        {
            return node is Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonObject json ? new AsyncOperationModel(json) : null;
        }

        /// <summary>
        /// Serializes this instance of <see cref="AsyncOperationModel" /> into a <see cref="Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonNode" />.
        /// </summary>
        /// <param name="container">The <see cref="Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonObject"/> container to serialize this object into. If the caller
        /// passes in <c>null</c>, a new instance will be created and returned to the caller.</param>
        /// <param name="serializationMode">Allows the caller to choose the depth of the serialization. See <see cref="Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.SerializationMode"/>.</param>
        /// <returns>
        /// a serialized instance of <see cref="AsyncOperationModel" /> as a <see cref="Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonNode" />.
        /// </returns>
        public Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonNode ToJson(Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonObject container, Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.SerializationMode serializationMode)
        {
            container = container ?? new Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonObject();

            bool returnNow = false;
            BeforeToJson(ref container, ref returnNow);
            if (returnNow)
            {
                return container;
            }
            if (serializationMode.HasFlag(Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.SerializationMode.IncludeReadOnly))
            {
                AddIf( null != this._context ? (Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonNode) this._context.ToJson(null,serializationMode) : null, "context" ,container.Add );
            }
            if (serializationMode.HasFlag(Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.SerializationMode.IncludeReadOnly))
            {
                AddIf( null != this._operation ? (Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonNode) this._operation.ToJson(null,serializationMode) : null, "operation" ,container.Add );
            }
            if (serializationMode.HasFlag(Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.SerializationMode.IncludeReadOnly))
            {
                AddIf( null != (((object)this._httpStatus)?.ToString()) ? (Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonNode) new Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonString(this._httpStatus.ToString()) : null, "httpStatus" ,container.Add );
            }
            if (serializationMode.HasFlag(Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.SerializationMode.IncludeReadOnly))
            {
                AddIf( null != (((object)this._id)?.ToString()) ? (Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonNode) new Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonString(this._id.ToString()) : null, "id" ,container.Add );
            }
            if (serializationMode.HasFlag(Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.SerializationMode.IncludeReadOnly))
            {
                AddIf( null != (((object)this._locationHeader)?.ToString()) ? (Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonNode) new Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonString(this._locationHeader.ToString()) : null, "locationHeader" ,container.Add );
            }
            if (serializationMode.HasFlag(Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.SerializationMode.IncludeReadOnly))
            {
                AddIf( null != (((object)this._operationEndTime)?.ToString()) ? (Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonNode) new Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonString(this._operationEndTime.ToString()) : null, "operationEndTime" ,container.Add );
            }
            if (serializationMode.HasFlag(Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.SerializationMode.IncludeReadOnly))
            {
                AddIf( null != (((object)this._operationStartTime)?.ToString()) ? (Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonNode) new Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonString(this._operationStartTime.ToString()) : null, "operationStartTime" ,container.Add );
            }
            if (serializationMode.HasFlag(Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.SerializationMode.IncludeReadOnly))
            {
                AddIf( null != (((object)this._response)?.ToString()) ? (Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonNode) new Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonString(this._response.ToString()) : null, "response" ,container.Add );
            }
            if (serializationMode.HasFlag(Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.SerializationMode.IncludeReadOnly))
            {
                AddIf( null != (((object)this._subscriptionId)?.ToString()) ? (Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonNode) new Microsoft.Azure.PowerShell.Cmdlets.StorageAdmin.Runtime.Json.JsonString(this._subscriptionId.ToString()) : null, "subscriptionId" ,container.Add );
            }
            AfterToJson(ref container);
            return container;
        }
    }
}