---
Module Name: Azs.Storage.Admin
Module Guid: fd5e1f12-9197-4df7-986d-3e676d6c3997
Download Help Link: https://docs.microsoft.com/en-us/powershell/module/azs.storage.admin
Help Version: 1.0.0.0
Locale: en-US
---

# Azs.Storage.Admin Module
## Description
Microsoft Azure PowerShell: StorageAdmin cmdlets

## Azs.Storage.Admin Cmdlets
### [Get-AzsStorageAccount](Get-AzsStorageAccount.md)
Returns the requested storage account.

### [Get-AzsStorageAcquisition](Get-AzsStorageAcquisition.md)
Returns a list of BLOB acquisitions.

### [Get-AzsStorageQuota](Get-AzsStorageQuota.md)


### [Get-AzsStorageSettings](Get-AzsStorageSettings.md)
Returns the storage resource provider settings.

### [New-AzsStorageQuota](New-AzsStorageQuota.md)


### [Remove-AzsStorageQuota](Remove-AzsStorageQuota.md)


### [Restore-AzsStorageAccount](Restore-AzsStorageAccount.md)


### [Set-AzsStorageQuota](Set-AzsStorageQuota.md)


### [Start-AzsReclaimStorageCapacity](Start-AzsReclaimStorageCapacity.md)


### [Update-AzsStorageSettings](Update-AzsStorageSettings.md)


